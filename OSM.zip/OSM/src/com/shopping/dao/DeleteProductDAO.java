package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.shopping.util.DBUtil;

public class DeleteProductDAO {
	public static boolean delete(String pid)
	{
		boolean status=false;  
		try{  
			
			 Connection con = DBUtil.getDBCon(); 
			      
			PreparedStatement ps=con.prepareStatement(  "delete from PRODUCT1 where PRODUCT_ID=?");  
			ps.setString(1,pid);  
			int result =ps.executeUpdate();
			  if(result>0)  
			{
		status=true;
		con.commit();
			}
			          
			}
			catch(Exception e)
			{
				System.out.println(e);
			}  
			return status;  
			}  
}

