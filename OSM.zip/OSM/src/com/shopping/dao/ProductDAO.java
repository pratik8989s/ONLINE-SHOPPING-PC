package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.shopping.beans.ProductBean;
import com.shopping.util.DBUtil;

public class ProductDAO {
	public boolean add(ProductBean pb)
	{
		boolean b = false;
		try{
			
			  Connection con = DBUtil.getDBCon(); 		
			
			PreparedStatement pstat = con.prepareStatement("insert into PRODUCT1 values(prod_seq.nextval,?,?,?,?,?,?,?)");
	

		pstat.setString(1, pb.getPname());
		pstat.setString(2, pb.getPcat());
		pstat.setString(3, pb.getPstatus());
		pstat.setString(4, pb.getPrice());
		pstat.setString(5, pb.getPdesc());
		pstat.setString(6, pb.getAdminid());
		pstat.setString(7, pb.getCatid());
		
		
		int result =pstat.executeUpdate();
		
		 if(result>0){
		    	b = true;
		    	con.commit();
		    }}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return b;
}
	
}

