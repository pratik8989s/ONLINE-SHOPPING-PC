package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.shopping.beans.ProductBean;
import com.shopping.util.DBUtil;

public class UpdateProductDAO {
	public boolean update(ProductBean pb)
	{
		boolean b = false;
		try{
			
			  Connection con = DBUtil.getDBCon(); 		
			
			PreparedStatement pstat = con.prepareStatement("UPDATE PRODUCT1 SET PRODUCT_ID=?,PRODUCT_NAME=?,PRODUCT_CATEGORY=?,PRODUCT_STATUS=?,PRODUCT_PRICE=?,PRODUCT_DESC=?,ADMIN_ID=?,CATEGORY_ID=? WHERE PRODUCT_ID=?");
	
		pstat.setString(1, pb.getPid());
		pstat.setString(2, pb.getPname());
		pstat.setString(3, pb.getPcat());
		pstat.setString(4, pb.getPstatus());
		pstat.setString(5, pb.getPrice());
		pstat.setString(6, pb.getPdesc());
		pstat.setString(7, pb.getAdminid());
		pstat.setString(8, pb.getCatid());
		pstat.setString(9, pb.getPid());
		
		
		int result =pstat.executeUpdate();
		
		 if(result==1){
		    	b = true;
		    	con.commit();
		    }}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return b;
}
	
}
