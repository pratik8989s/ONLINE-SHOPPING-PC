package com.shopping.beans;

public class CartBean{
	
	private String pid;
	private String price;
	
	public void Items(String pid, String price) {
		
		
		this.pid = pid;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Items [pid=" + pid + ", price=" + price + "]";
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		pid = pid;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}


}
